"""Learning lesson model."""

from __future__ import annotations

from datetime import datetime

from extensions import db


class Lesson(db.Model):
    """A learning lesson for civic education."""

    __tablename__ = "lessons"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    slug = db.Column(db.String(180), unique=True, nullable=False, index=True)
    summary = db.Column(db.String(255), nullable=False)
    content = db.Column(db.Text, nullable=False)
    order = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    progresses = db.relationship("LessonProgress", back_populates="lesson", cascade="all, delete-orphan")

    @property
    def completion_count(self) -> int:
        return len(self.progresses)
