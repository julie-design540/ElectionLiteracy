"""Public-facing pages."""

from __future__ import annotations

from flask import Blueprint, render_template, request

from models import Artwork, Category

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def home():
    featured = Artwork.query.filter_by(status="approved", is_featured=True).order_by(Artwork.created_at.desc()).limit(6)
    latest = Artwork.query.filter_by(status="approved").order_by(Artwork.created_at.desc()).limit(12)
    categories = Category.query.order_by(Category.name.asc()).all()
    return render_template("home.html", featured=featured, latest=latest, categories=categories)


@main_bp.route("/gallery")
def gallery():
    query = request.args.get("q", "").strip()
    category_id = request.args.get("category", type=int)
    sort = request.args.get("sort", "newest")

    artworks = Artwork.query.filter_by(status="approved")
    if query:
        search_term = f"%{query}%"
        artworks = artworks.filter(Artwork.title.ilike(search_term) | Artwork.description.ilike(search_term))
    if category_id:
        artworks = artworks.filter_by(category_id=category_id)
    if sort == "popular":
        artworks = artworks.order_by(Artwork.download_count.desc(), Artwork.created_at.desc())
    else:
        artworks = artworks.order_by(Artwork.created_at.desc())

    return render_template(
        "gallery.html",
        artworks=artworks.all(),
        categories=Category.query.order_by(Category.name.asc()).all(),
        query=query,
        selected_category=category_id,
        selected_sort=sort,
    )
