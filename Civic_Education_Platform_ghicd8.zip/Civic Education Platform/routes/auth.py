"""Authentication routes."""

from __future__ import annotations

from pathlib import Path

from flask import Blueprint, flash, redirect, render_template, request, url_for, current_app
from flask_login import current_user, login_required, login_user, logout_user
from sqlalchemy import func, or_
from werkzeug.utils import secure_filename

from extensions import db
from forms import ChangePasswordForm, LoginForm, ProfileForm, RegisterForm
from models import Artwork, Comment, Favourite, Like, Share, User

auth_bp = Blueprint("auth", __name__)


def _save_profile_image(uploaded_file) -> str:
    filename = secure_filename(uploaded_file.filename or "")
    if not filename:
        return ""
    destination = Path(current_app.config["PROFILE_UPLOAD_FOLDER"]) / filename
    uploaded_file.save(destination)
    return filename


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    form = RegisterForm()
    if form.validate_on_submit():
        if User.query.filter(or_(User.username == form.username.data, User.email == form.email.data)).first():
            flash("Username or email already exists.", "warning")
        else:
            user = User(username=form.username.data, email=form.email.data)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash("Account created successfully. Please log in.", "success")
            return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter(or_(User.username == form.identifier.data, User.email == form.identifier.data)).first()
        if user is None or not user.check_password(form.password.data):
            flash("Invalid login details.", "danger")
        else:
            login_user(user)
            flash("Welcome back.", "success")
            return redirect(request.args.get("next") or url_for("main.home"))
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.home"))


@auth_bp.route("/profile")
@login_required
def profile():
    artworks = current_user.artworks
    favourites = [item.artwork for item in current_user.favourites]
    engagement_stats = {
        "likes_received": db.session.query(func.count(Like.id))
        .join(Artwork, Like.artwork_id == Artwork.id)
        .filter(Artwork.user_id == current_user.id)
        .scalar(),
        "shares_received": db.session.query(func.count(Share.id))
        .join(Artwork, Share.artwork_id == Artwork.id)
        .filter(Artwork.user_id == current_user.id)
        .scalar(),
        "downloads_received": db.session.query(func.coalesce(func.sum(Artwork.download_count), 0))
        .filter(Artwork.user_id == current_user.id)
        .scalar(),
        "comments_received": db.session.query(func.count(Comment.id))
        .join(Artwork, Comment.artwork_id == Artwork.id)
        .filter(Artwork.user_id == current_user.id)
        .scalar(),
    }
    total_engagements = (
        engagement_stats["likes_received"]
        + engagement_stats["shares_received"]
        + engagement_stats["downloads_received"]
        + engagement_stats["comments_received"]
    )
    engagement_stats["average_interactions_per_post"] = round(total_engagements / max(len(artworks), 1), 1)
    top_artworks = sorted(
        artworks,
        key=lambda item: (item.like_count + item.share_count + item.download_count + item.favourite_count, item.created_at),
        reverse=True,
    )[:3]
    return render_template(
        "auth/profile.html",
        artworks=artworks,
        favourites=favourites,
        engagement_stats=engagement_stats,
        top_artworks=top_artworks,
    )


@auth_bp.route("/profile/edit", methods=["GET", "POST"])
@login_required
def edit_profile():
    form = ProfileForm(obj=current_user)
    if form.validate_on_submit():
        duplicate = User.query.filter(
            or_(User.username == form.username.data, User.email == form.email.data)
        ).filter(User.id != current_user.id).first()
        if duplicate:
            flash("Username or email is already in use.", "warning")
            return render_template("auth/edit_profile.html", form=form)
        current_user.username = form.username.data
        current_user.email = form.email.data
        current_user.bio = form.bio.data or ""
        if form.profile_image.data:
            current_user.profile_image = _save_profile_image(form.profile_image.data)
        db.session.commit()
        flash("Profile updated successfully.", "success")
        return redirect(url_for("auth.profile"))
    return render_template("auth/edit_profile.html", form=form)


@auth_bp.route("/profile/password", methods=["GET", "POST"])
@login_required
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash("Current password is incorrect.", "danger")
        else:
            current_user.set_password(form.new_password.data)
            db.session.commit()
            flash("Password updated successfully.", "success")
            return redirect(url_for("auth.profile"))
    return render_template("auth/change_password.html", form=form)
