document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById("page-loader");
  if (loader) {
    window.setTimeout(() => loader.classList.add("is-hidden"), 180);
  }

  const themeToggle = document.getElementById("themeToggle");
  const root = document.documentElement;
  const storedTheme = window.localStorage.getItem("theme") || "light";
  const themeIcon = themeToggle ? themeToggle.querySelector("i") : null;
  root.setAttribute("data-theme", storedTheme);
  if (themeIcon) {
    themeIcon.className = storedTheme === "dark" ? "bi bi-sun-fill" : "bi bi-moon-stars";
  }

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const nextTheme = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", nextTheme);
      window.localStorage.setItem("theme", nextTheme);
      if (themeIcon) {
        themeIcon.className = nextTheme === "dark" ? "bi bi-sun-fill" : "bi bi-moon-stars";
      }
    });
  }

  const counters = document.querySelectorAll("[data-count]");
  const animateCounter = (element) => {
    const target = Number(element.dataset.count || 0);
    const duration = 900;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      element.textContent = Math.floor(progress * target).toLocaleString();
      if (progress < 1) {
        window.requestAnimationFrame(tick);
      } else {
        element.textContent = target.toLocaleString();
      }
    };
    window.requestAnimationFrame(tick);
  };

  if (counters.length) {
    counters.forEach((counter) => animateCounter(counter));
  }

  const toastEls = document.querySelectorAll(".toast");
  if (toastEls.length) {
    toastEls.forEach((toast) => {
      window.setTimeout(() => toast.classList.remove("show"), 4500);
    });
  }

  const revealTargets = document.querySelectorAll(".reveal-card, .glass-card, .art-card, .mini-activity, .queue-card");
  if ("IntersectionObserver" in window && revealTargets.length) {
    revealTargets.forEach((element) => element.classList.add("reveal-ready"));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealTargets.forEach((element) => observer.observe(element));
  }

  const chartElement = document.getElementById("statusChart");
  if (chartElement && window.Chart) {
    const labels = JSON.parse(chartElement.dataset.labels || "[]");
    const values = JSON.parse(chartElement.dataset.values || "[]");
    new Chart(chartElement, {
      type: "doughnut",
      data: {
        labels,
        datasets: [
          {
            data: values,
            backgroundColor: ["#f59e0b", "#2563eb", "#1e3a8a"],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: "bottom",
          },
        },
      },
    });
  }

  const artworkInput = document.getElementById("artwork-image-input");
  const artworkDropzone = document.getElementById("artworkDropzone");
  const artworkPreviewImage = document.getElementById("artworkPreviewImage");
  const artworkPreview = document.getElementById("artworkPreview");
  const artworkFileName = document.getElementById("artworkFileName");

  const renderArtworkPreview = (file) => {
    if (!file || !artworkPreviewImage || !artworkPreview || !artworkFileName) {
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      artworkPreviewImage.src = String(event.target?.result || "");
      artworkPreviewImage.classList.remove("d-none");
      artworkPreview.classList.add("d-none");
      artworkFileName.textContent = file.name;
    };
    reader.readAsDataURL(file);
  };

  if (artworkInput) {
    artworkInput.addEventListener("change", () => {
      const [file] = artworkInput.files || [];
      renderArtworkPreview(file);
    });
  }

  if (artworkDropzone) {
    artworkDropzone.addEventListener("dragover", (event) => {
      event.preventDefault();
      artworkDropzone.classList.add("is-dragover");
    });
    artworkDropzone.addEventListener("dragleave", () => {
      artworkDropzone.classList.remove("is-dragover");
    });
    artworkDropzone.addEventListener("drop", (event) => {
      event.preventDefault();
      artworkDropzone.classList.remove("is-dragover");
      if (artworkInput && event.dataTransfer?.files?.length) {
        const transfer = new DataTransfer();
        transfer.items.add(event.dataTransfer.files[0]);
        artworkInput.files = transfer.files;
        renderArtworkPreview(event.dataTransfer.files[0]);
      }
    });
  }
});
