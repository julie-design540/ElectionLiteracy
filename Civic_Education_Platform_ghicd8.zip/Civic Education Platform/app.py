"""Application entry point for the civic education platform."""

from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, render_template
from werkzeug.security import generate_password_hash

from config import config_by_name
from extensions import csrf, db, login_manager
from models import Artwork, Category, User
from routes.admin import admin_bp
from routes.artwork import artwork_bp
from routes.auth import auth_bp
from routes.main import main_bp


def create_app(config_name: str | None = None) -> Flask:
    """Create and configure the Flask application."""

    app = Flask(__name__, instance_relative_config=True)
    config_key = config_name or os.getenv("FLASK_CONFIG", "development")
    app.config.from_object(config_by_name[config_key])

    instance_path = Path(app.instance_path)
    upload_dir = Path(app.static_folder or "static") / "uploads"
    profile_dir = upload_dir / "profiles"
    artwork_dir = upload_dir / "artworks"
    for directory in (instance_path, upload_dir, profile_dir, artwork_dir):
        directory.mkdir(parents=True, exist_ok=True)

    app.config["UPLOAD_FOLDER"] = str(upload_dir)
    app.config["PROFILE_UPLOAD_FOLDER"] = str(profile_dir)
    app.config["ARTWORK_UPLOAD_FOLDER"] = str(artwork_dir)

    db.init_app(app)
    csrf.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(artwork_bp, url_prefix="/artwork")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    @app.context_processor
    def inject_globals() -> dict[str, object]:
        """Make common counts and categories available in every template."""

        return {
            "category_list": Category.query.order_by(Category.name.asc()).all(),
            "featured_count": Artwork.query.filter_by(status="approved").count(),
            "user_count": User.query.count(),
        }

    @app.errorhandler(404)
    def page_not_found(_error: Exception):
        return render_template("errors/404.html"), 404

    @app.cli.command("seed-data")
    def seed_data() -> None:
        """Populate the database with default categories and an admin user."""

        default_categories = [
            "Peace",
            "Democracy",
            "Voting Process",
            "Youth Participation",
            "Constitution",
            "Leadership",
            "Anti-Corruption",
            "Women's Participation",
            "Disability Inclusion",
            "Election Integrity",
        ]

        for name in default_categories:
            Category.get_or_create(name=name, description=f"Artwork about {name.lower()}.")

        admin_email = app.config.get("SEED_ADMIN_EMAIL", "admin@civicart.local")
        admin_username = app.config.get("SEED_ADMIN_USERNAME", "admin")
        admin_password = app.config.get("SEED_ADMIN_PASSWORD", "Admin@12345")
        admin = User.query.filter_by(email=admin_email).first()
        if admin is None:
            admin = User(
                username=admin_username,
                email=admin_email,
                role="admin",
                password_hash=generate_password_hash(admin_password),
            )
            db.session.add(admin)
        db.session.commit()
        print("Seed data created successfully.")

    with app.app_context():
        db.create_all()
        if not Category.query.first():
            for name in [
                "Peace",
                "Democracy",
                "Voting Process",
                "Youth Participation",
                "Constitution",
                "Leadership",
                "Anti-Corruption",
                "Women's Participation",
                "Disability Inclusion",
                "Election Integrity",
            ]:
                Category.get_or_create(name=name, description=f"Artwork about {name.lower()}.")

        admin_email = app.config.get("SEED_ADMIN_EMAIL", "admin@civicart.local")
        admin_username = app.config.get("SEED_ADMIN_USERNAME", "admin")
        admin_password = app.config.get("SEED_ADMIN_PASSWORD", "Admin@12345")
        if not User.query.filter_by(email=admin_email).first():
            db.session.add(
                User(
                    username=admin_username,
                    email=admin_email,
                    role="admin",
                    password_hash=generate_password_hash(admin_password),
                )
            )
        db.session.commit()

    return app


app = create_app()


if __name__ == "__main__":
    app.run(
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG", "0") == "1",
        use_reloader=False,
    )
