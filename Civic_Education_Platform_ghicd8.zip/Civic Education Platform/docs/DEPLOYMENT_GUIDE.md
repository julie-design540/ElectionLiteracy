# Deployment Guide

## Production Checklist

- Set a strong `SECRET_KEY`
- Use a production WSGI server
- Update the database URI if needed
- Restrict file upload types
- Configure backups for the SQLite file

## Recommended Deployment Flow

1. Install dependencies.
2. Run the seed command once.
3. Start the application behind a reverse proxy.
4. Place static files behind a web server if desired.

## Notes

This project is intentionally simple and uses SQLite, so it is best suited for demonstrations, academic submissions, and small deployments.
